﻿namespace BookStore.Models.Requests
{
    public class SomeRequest
    {
        public int SomeIntValue { get; set; }

        public string Name { get; set; }
    }
}
